
module.exports = {
    helloDynamicFunc: async (res) => {
        res.status(200).json({
            message: 'Hello dynamic func'
        })

        res.end()
    }
}